#ifndef WINDOW_HEADER
#define WINDOW_HEADER

// window variables
const int WINDOW_WIDTH = 600;
const int WINDOW_HEIGHT = 400;
const int WINDOW_X = 100;
const int WINDOW_Y = 60;

const char* WINDOW_TITLE = "Flappy Bird in C!";

#endif